﻿using System;

namespace pos.BL
{
    public class Class1
    {
    }
}
