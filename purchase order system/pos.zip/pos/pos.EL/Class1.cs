﻿using System;

namespace pos.EL
{
    public class Class1
    {
    }
}
