﻿using System;


namespace pos.DL
{
    public class Class1
    {
    }
}
