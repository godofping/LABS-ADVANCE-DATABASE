﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace barangay.EL.Registrations
{
    public class Occupations
    {
        int occupationid;
        string occupation;

        public int Occupationid { get => occupationid; set => occupationid = value; }
        public string Occupation { get => occupation; set => occupation = value; }
    }
}
