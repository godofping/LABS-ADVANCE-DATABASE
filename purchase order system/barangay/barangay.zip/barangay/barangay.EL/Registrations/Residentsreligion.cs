﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace barangay.EL.Registrations
{
    public class Residentsreligion
    {
        int residentreligionid;
        int residentid;
        int religionid;

        public int Residentreligionid { get => residentreligionid; set => residentreligionid = value; }
        public int Residentid { get => residentid; set => residentid = value; }
        public int Religionid { get => religionid; set => religionid = value; }
    }
}
