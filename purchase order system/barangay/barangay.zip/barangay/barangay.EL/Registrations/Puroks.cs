﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace barangay.EL.Registrations
{
    public class Puroks
    {
        int purokid;
        string purok;

        public int Purokid { get => purokid; set => purokid = value; }
        public string Purok { get => purok; set => purok = value; }
    }
}
