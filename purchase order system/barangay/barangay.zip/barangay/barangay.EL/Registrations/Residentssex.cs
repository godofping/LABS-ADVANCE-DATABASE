﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace barangay.EL.Registrations
{
    public class Residentssex
    {
        int residentsexid;
        int residentid;
        int sexid;

        public int Residentsexid { get => residentsexid; set => residentsexid = value; }
        public int Residentid { get => residentid; set => residentid = value; }
        public int Sexid { get => sexid; set => sexid = value; }
    }
}
