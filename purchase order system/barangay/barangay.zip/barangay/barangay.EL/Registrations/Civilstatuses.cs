﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace barangay.EL.Registrations
{
    public class Civilstatuses
    {
        int civilstatusid;
        string civilstatus;

        public int Civilstatusid { get => civilstatusid; set => civilstatusid = value; }
        public string Civilstatus { get => civilstatus; set => civilstatus = value; }
    }
}
