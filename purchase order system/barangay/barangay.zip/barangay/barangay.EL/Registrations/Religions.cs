﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace barangay.EL.Registrations
{
    public class Religions
    {
        int religionid;
        string religion;

        public int Religionid { get => religionid; set => religionid = value; }
        public string Religion { get => religion; set => religion = value; }
    }
}
