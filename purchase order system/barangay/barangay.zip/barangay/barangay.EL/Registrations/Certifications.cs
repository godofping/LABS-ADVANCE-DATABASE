﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace barangay.EL.Registrations
{
    public class Certifications
    {
        int certificationid;
        string certification;

        public int Certificationid { get => certificationid; set => certificationid = value; }
        public string Certification { get => certification; set => certification = value; }
    }
}
