﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace barangay.EL.Registrations
{
    public class Sexes
    {
        int sexid;
        string sex;

        public int Sexid { get => sexid; set => sexid = value; }
        public string Sex { get => sex; set => sex = value; }
    }
}
