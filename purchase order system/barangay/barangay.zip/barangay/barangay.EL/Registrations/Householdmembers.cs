﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace barangay.EL.Registrations
{
    public class Householdmembers
    {
        int householdmemberid;
        string householdmember;

        public int Householdmemberid { get => householdmemberid; set => householdmemberid = value; }
        public string Householdmember { get => householdmember; set => householdmember = value; }
    }
}
