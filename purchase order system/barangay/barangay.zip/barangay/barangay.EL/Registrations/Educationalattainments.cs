﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace barangay.EL.Registrations
{
    public class Educationalattainments
    {
        int educationalattainmentid;
        string educationalattainment;

        public int Educationalattainmentid { get => educationalattainmentid; set => educationalattainmentid = value; }
        public string Educationalattainment { get => educationalattainment; set => educationalattainment = value; }
    }
}
