﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace barangay.EL.Registrations
{
    public class Citizenships
    {
        int citizenshipid;
        string citizenship;

        public int Citizenshipid { get => citizenshipid; set => citizenshipid = value; }
        public string Citizenship { get => citizenship; set => citizenship = value; }
    }
}
