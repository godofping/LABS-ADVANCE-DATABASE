﻿namespace barangay.PL.Transactions
{


    partial class dsBarangay
    {
    }
}
