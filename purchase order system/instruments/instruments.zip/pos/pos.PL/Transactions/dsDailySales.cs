﻿namespace pos.PL.Transactions
{


    partial class dsDailySales
    {
        partial class transactionsDataTable
        {
        }

        partial class transactions_viewDataTable
        {
        }
    }
}
