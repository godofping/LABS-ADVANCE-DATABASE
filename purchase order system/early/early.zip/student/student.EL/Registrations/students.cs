﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace student.EL.Registrations
{
    public class students
    {
        int studentid;

        public int Studentid
        {
            get { return studentid; }
            set { studentid = value; }
        }
        int strandid;

        public int Strandid
        {
            get { return strandid; }
            set { strandid = value; }
        }
        string lrn;

        public string Lrn
        {
            get { return lrn; }
            set { lrn = value; }
        }
        string lastname;

        public string Lastname
        {
            get { return lastname; }
            set { lastname = value; }
        }
        string firstname;

        public string Firstname
        {
            get { return firstname; }
            set { firstname = value; }
        }
        string middleinitial;

        public string Middleinitial
        {
            get { return middleinitial; }
            set { middleinitial = value; }
        }

        string gender;

        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        string address;

        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        string parentsorguardian;

        public string Parentsorguardian
        {
            get { return parentsorguardian; }
            set { parentsorguardian = value; }
        }
        string contactnumber;

        public string Contactnumber
        {
            get { return contactnumber; }
            set { contactnumber = value; }
        }
        string lastschoolattended;

        public string Lastschoolattended
        {
            get { return lastschoolattended; }
            set { lastschoolattended = value; }
        }
        string schoolyear;

        public string Schoolyear
        {
            get { return schoolyear; }
            set { schoolyear = value; }
        }
        string yearlevel;

        public string Yearlevel
        {
            get { return yearlevel; }
            set { yearlevel = value; }
        }

        string dateadded;

        public string Dateadded
        {
            get { return dateadded; }
            set { dateadded = value; }
        }


    }
}
