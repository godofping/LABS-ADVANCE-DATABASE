﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace student.EL.Registrations
{
    public class strands
    {
        int strandid;

        public int Strandid
        {
            get { return strandid; }
            set { strandid = value; }
        }
        string strand;

        public string Strand
        {
            get { return strand; }
            set { strand = value; }
        }

        string stranddescription;

        public string Stranddescription
        {
            get { return stranddescription; }
            set { stranddescription = value; }
        }
    }
}
