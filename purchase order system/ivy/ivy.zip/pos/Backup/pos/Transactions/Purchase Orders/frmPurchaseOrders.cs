﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace pos.Transactions.Purchase_Orders
{
    public partial class frmPurchaseOrders : Form
    {
        public frmPurchaseOrders()
        {
            InitializeComponent();
        }
    }
}
