﻿namespace pos.EL.Registrations
{
    public class ShippingMethods
    {
        int shippingmethodid;
        string shippingmethod;

        public int Shippingmethodid { get => shippingmethodid; set => shippingmethodid = value; }
        public string Shippingmethod { get => shippingmethod; set => shippingmethod = value; }
    }
}
