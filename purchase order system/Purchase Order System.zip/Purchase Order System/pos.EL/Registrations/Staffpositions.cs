﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pos.EL.Registrations
{
    public class Staffpositions
    {
        int staffpositionid;
        string staffposition;

        public int Staffpositionid { get => staffpositionid; set => staffpositionid = value; }
        public string Staffposition { get => staffposition; set => staffposition = value; }
    }
}
