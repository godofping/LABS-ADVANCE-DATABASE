﻿namespace pos.EL.Registrations
{
    public class PaymentMethods
    {
        int paymentmethodid;
        string paymentmethod;

        public int Paymentmethodid { get => paymentmethodid; set => paymentmethodid = value; }
        public string Paymentmethod { get => paymentmethod; set => paymentmethod = value; }
    }
}
