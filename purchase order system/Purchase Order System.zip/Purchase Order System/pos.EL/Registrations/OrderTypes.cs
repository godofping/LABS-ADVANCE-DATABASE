﻿namespace pos.EL.Registrations
{
    public class OrderTypes
    {
        int ordertypeid;
        string ordertype;

        public int Ordertypeid { get => ordertypeid; set => ordertypeid = value; }
        public string Ordertype { get => ordertype; set => ordertype = value; }
    }
}
