﻿namespace pos.EL.Registrations
{
    public class StoreInformation
    {
        string storename;
        int contactdetailid;

        public string Storename { get => storename; set => storename = value; }
        public int Contactdetailid { get => contactdetailid; set => contactdetailid = value; }
    }
}
