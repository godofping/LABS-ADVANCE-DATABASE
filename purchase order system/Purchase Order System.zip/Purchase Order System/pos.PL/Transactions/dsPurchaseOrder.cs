﻿namespace pos.PL.Transactions
{


    partial class dsPurchaseOrder
    {

    }
}
