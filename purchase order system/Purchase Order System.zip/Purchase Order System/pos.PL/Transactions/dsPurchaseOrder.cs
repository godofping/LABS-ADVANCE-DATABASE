﻿namespace pos.PL.Transactions
{


    partial class dsPurchaseOrder
    {
        partial class testDataTable
        {
        }

        partial class dtStoreinformation_viewDataTable
        {
        }
    }
}
