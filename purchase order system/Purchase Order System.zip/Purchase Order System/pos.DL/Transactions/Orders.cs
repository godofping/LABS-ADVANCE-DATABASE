﻿

namespace pos.DL.Transactions
{
    public class Orders
    {
    }
}
