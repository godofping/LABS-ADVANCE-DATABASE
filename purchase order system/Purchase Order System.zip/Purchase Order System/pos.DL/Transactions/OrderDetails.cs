﻿
namespace pos.DL.Transactions
{
    public class OrderDetails
    {
    }
}
