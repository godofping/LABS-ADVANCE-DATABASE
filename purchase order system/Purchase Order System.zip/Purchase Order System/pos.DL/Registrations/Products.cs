﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pos.DL.Registrations
{
    class Products
    {
    }
}
