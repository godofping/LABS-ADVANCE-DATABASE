﻿
namespace pos.BL.Transactions
{
    public class Orders
    {
    }
}
