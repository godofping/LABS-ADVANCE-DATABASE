﻿
namespace pos.BL.Transactions
{
   public class OrderDetails
    {
    }
}
